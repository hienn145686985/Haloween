// Server cho Hội Halloween Online
// Chạy: npm install && npm start  -> mở http://localhost:3000

const http = require("http");
const fs = require("fs");
const path = require("path");
const { WebSocketServer } = require("ws");

const PORT = process.env.PORT || 3000;
const BASE_COUNT = 16253;   // số hiển thị cơ sở; người thật đang kết nối được cộng thêm
const SLOT_COUNT = 60;      // số chỗ ngồi/đứng trong hội
const CHAT_MIN_GAP = 800;   // ms giữa 2 tin nhắn của cùng một người
const LIGHT_REWARD = 5;     // vàng nhận được mỗi lần thắp đèn
const LIGHT_GAP = 1000;     // ms tối thiểu giữa 2 lần thắp đèn được thưởng
const START_COINS = 20;
const ACTIONS = new Set(["join", "bow", "light"]);

// Vật phẩm chỉ mua bằng vàng kiếm được trong game. Không bán bằng tiền thật.
const ITEMS = {
  witch:   { name: "Mũ phù thủy",     price: 30 },
  cape:    { name: "Áo choàng dơi",   price: 50 },
  pumpkin: { name: "Bí ngô cầm tay",  price: 20 },
};

const page = fs.readFileSync(path.join(__dirname, "chua-halloween.html"));
const qrPath = path.join(__dirname, "momo-qr.jpg");

const server = http.createServer((req, res) => {
  const url = req.url.split("?")[0];
  if (url === "/") {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    return res.end(page);
  }
  if (url === "/momo-qr.jpg") {
    return fs.readFile(qrPath, (err, data) => {
      if (err) { res.writeHead(404); return res.end(); }
      res.writeHead(200, { "Content-Type": "image/jpeg" });
      res.end(data);
    });
  }
  res.writeHead(404, { "Content-Type": "text/plain" });
  res.end("Not found");
});

const wss = new WebSocketServer({ server, path: "/ws" });
const players = new Map(); // id -> player
let nextId = 1;

function freeSlot() {
  const used = new Set([...players.values()].map((p) => p.slot));
  for (let i = 0; i < SLOT_COUNT; i++) if (!used.has(i)) return i;
  return null; // hội đã đủ chỗ: người này đứng xem
}

function sendTo(ws, obj) {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
}

function broadcast(obj) {
  const data = JSON.stringify(obj);
  for (const c of wss.clients) if (c.readyState === 1) c.send(data);
}

function sendWallet(p) {
  sendTo(p.ws, { t: "wallet", coins: p.coins, owned: p.owned, equip: p.equip });
}

function broadcastState() {
  broadcast({
    t: "state",
    count: BASE_COUNT + players.size,
    players: [...players.values()].map((p) => ({
      id: p.id, name: p.name, slot: p.slot, a: p.a, actAt: p.actAt, equip: p.equip,
    })),
  });
}

wss.on("connection", (ws) => {
  const id = "p" + nextId++;
  let player = null;

  ws.on("message", (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }

    if (msg.t === "hello" && !player) {
      const name = String(msg.name || "").trim().slice(0, 20) || "Khách";
      player = {
        id, name, ws, slot: freeSlot(), a: null, actAt: 0,
        lastChat: 0, lastLight: 0,
        coins: START_COINS, owned: [], equip: null,
      };
      players.set(id, player);
      sendTo(ws, { t: "welcome", id, slot: player.slot, items: ITEMS });
      sendWallet(player);
      broadcast({ t: "sys", text: `${player.name} vừa vào hội.` });
      broadcastState();
    } else if (msg.t === "act" && player && ACTIONS.has(msg.a)) {
      const now = Date.now();
      player.a = msg.a;
      player.actAt = now;
      if (msg.a === "light" && now - player.lastLight >= LIGHT_GAP) {
        player.lastLight = now;
        player.coins += LIGHT_REWARD;
        sendWallet(player);
      }
    } else if (msg.t === "chat" && player) {
      const now = Date.now();
      const text = String(msg.text || "").trim().slice(0, 120);
      if (!text || now - player.lastChat < CHAT_MIN_GAP) return;
      player.lastChat = now;
      broadcast({ t: "chat", name: player.name, slot: player.slot, text });
    } else if (msg.t === "buy" && player) {
      const item = ITEMS[msg.item];
      if (!item) return;
      if (player.owned.includes(msg.item)) {
        return sendTo(ws, { t: "notice", text: `Bạn đã có ${item.name}.` });
      }
      if (player.coins < item.price) {
        return sendTo(ws, { t: "notice", text: `Chưa đủ vàng để mua ${item.name}.` });
      }
      player.coins -= item.price;
      player.owned.push(msg.item);
      sendWallet(player);
      sendTo(ws, { t: "notice", text: `Đã mua ${item.name}. Bấm Đeo để mặc vào.` });
    } else if (msg.t === "equip" && player) {
      if (msg.item === null) {
        player.equip = null;
      } else if (ITEMS[msg.item] && player.owned.includes(msg.item)) {
        player.equip = msg.item;
      } else {
        return;
      }
      sendWallet(player);
      broadcastState();
    }
  });

  ws.on("close", () => {
    if (player) {
      players.delete(id);
      broadcast({ t: "sys", text: `${player.name} vừa rời hội.` });
    }
    broadcastState();
  });
});

// Gửi trạng thái đều đặn để mọi máy khách thấy nhau
setInterval(broadcastState, 150);

server.listen(PORT, () => {
  console.log(`Hội Halloween đang chạy tại http://localhost:${PORT}`);
});
